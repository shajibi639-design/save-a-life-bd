Save a Life BD v2
1. Upload index.html to GitHub repository root, replacing the old index.html. Commit changes.
2. In Firebase Authentication > Sign-in method, enable Email/Password.
3. In Firebase Authentication > Settings > Authorized domains, add shajibi639-design.github.io if absent.
4. In Firebase Firestore > Rules, replace the old rules with firestore.rules content and Publish. Review rules carefully; existing app collections beyond users are denied by this version.
5. Refresh the GitHub Pages URL after deployment.
Important: Districts are preloaded, but upazila/union/village are free-text inputs, not verified administrative datasets. Donor contact numbers are stored separately in donorContacts and only readable by their owner. A consent-based secure contact request workflow is not yet available. SOS is database storage only, not dispatch. No verified hospital directory or admin verification workflow is included.
